from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.models.order import Order

router = APIRouter(tags=["design"])


@router.get("/api/orders/{order_id}/previews")
def get_order_previews(order_id: str, db: Session = Depends(get_db)):
    """Return design previews for the client selection page."""
    order = db.query(Order).filter(Order.id == order_id).first()

    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    previews = getattr(order, "design_previews", None) or []
    logo_previews = getattr(order, "logo_previews", None) or []

    return {
        "success": True,
        "order_id": order.id,
        "status": order.status,
        "previews": previews,
        "design_previews": previews,
        "logo_previews": logo_previews,
        "selected_design_id": getattr(order, "selected_design_id", None),
        "selected_screenshot_url": getattr(order, "selected_screenshot_url", None),
    }
